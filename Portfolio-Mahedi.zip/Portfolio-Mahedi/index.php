<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// PHPMailer Autoload
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$messageSent = false;
$errorMessage = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = htmlspecialchars($_POST['name']);
    $email   = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'mahedihasanabir8@gmail.com';
        $mail->Password   = 'ypqtffksztrujgay';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('mahedihasanabir8@gmail.com', 'Mahedi Hasan Abir');
        $mail->addAddress('idbmahedi@gmail.com');
        $mail->addReplyTo($email, $name);

        $mail->isHTML(true);
        $mail->Subject = "New Contact Message";
        $mail->Body    = "<h3>New Message</h3>
                          <p><b>Name:</b> $name</p>
                          <p><b>Email:</b> $email</p>
                          <p><b>Message:</b><br>$message</p>";
        $mail->AltBody = "Name: $name\nEmail: $email\nMessage:\n$message";

        $mail->send();
        $messageSent = true;

    } catch (Exception $e) {
        $errorMessage = "Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Developer Portfolio</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Oswald:300,400' rel='stylesheet'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet'>
</head>
<body>
<!-- Header -->
<div class="content-block" id="header">
    <div id="overlay-1">
        <header id="site-header" class="clearfix">
            <div class="pull-left">
                <h1><a href="#">Programmer-Mahedi</a></h1>
            </div>
            <div class="pull-right">
                <nav class="navbar site-nav">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                            <i class="fa fa-bars fa-2x"></i>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="navbar-collapse">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="#header"><i class="fa fa-home"></i> Home</a></li>
                            <li><a href="#projects"><i class="fa fa-bookmark"></i> Projects</a></li>
                            <li><a href="#services"><i class="fa fa-bullhorn"></i> Profile</a></li>
                            <li><a href="#feedback"><i class="fa fa-thumbs-up"></i> Feedback</a></li>
                            <li><a href="#contact"><i class="fa fa-phone-square"></i> Contact</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </header>

        <div class="middle text-center clearfix">
            <div class="container">
                <h1 class="pro-name">Web Developer</h1>
                <p class="tagline">Design. Develop. Deliver.</p>
                <a href="#contact" class="btn btn-lg btn-hire wow animated zoomIn">Hire Me</a>
            </div>
        </div>
        <div class="bottom text-center">
            <a href="#projects"><i class="fa fa-angle-down fa-3x pulse"></i></a>
        </div>
    </div>
</div>

<!-- Projects Section -->
<div class="content-block text-center" id="projects">
    <header class="block-heading clearfix"><h1>My Projects</h1></header>
    <div class="isotope projects-items row">
        <!-- Example Project Items -->
        <?php
        $projects = [
            ['url'=>'https://shohoz-project.netlify.app/', 'img'=>'img/work1.jpg', 'title'=>'SHOHOZ.COM'],
            ['url'=>'https://programmermahedihasan.github.io/InnoCraft/', 'img'=>'img/work2.jpg', 'title'=>'INNOCRAFT'],
            ['url'=>'http://mahedi.intelsofts.com/Php%20Project/admin/', 'img'=>'img/work3.jpg', 'title'=>'NEXTPRIME'],
            ['url'=>'http://mahedi.intelsofts.com/React%20Project/admin/', 'img'=>'img/work4.jpg', 'title'=>'HRMS & PAYROLL'],
        ];
        foreach($projects as $p){
            echo '<div class="element-item col-md-3 col-sm-6 col-xs-12">
                    <div class="effect-zoe">
                        <a href="'.$p['url'].'" target="_blank">
                            <img class="img-responsive project-image" src="'.$p['img'].'" alt="'.$p['title'].'">
                            <figcaption><h2 class="hidden-xs">'.$p['title'].'</h2></figcaption>
                        </a>
                    </div>
                  </div>';
        }
        ?>
    </div>
</div>

<!-- Profile Section -->
<div id="services" class="content-block">
    <div class="parallax overlay">
        <div class="container">
            <div class="row block-heading text-center"><h1>A Quick Overview of My Profile</h1></div>
            <div class="row text-center numbersList">
                <?php
                $profile_stats = [
                    'Conferences'=>101,
                    'Lines of Code'=>92,
                    'Hours of Work'=>54,
                    'Repositories in Git'=>99,
                    'Mobile APP'=>124,
                    'Happy Client'=>45
                ];
                foreach($profile_stats as $title=>$num){
                    echo '<div class="col-md-2 col-sm-4 col-xs-6"><h4>'.$title.'</h4><span class="count">'.$num.'</span></div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<!-- Feedback Section -->
<div class="content-block" id="feedback">
    <header class="block-heading text-center"><h1>Clients Feedback!</h1></header>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="owl-carousel owl-theme">
                    <?php
                    $feedbacks = [
                        ['img'=>'img/testimonial_31-190x190.jpg', 'text'=>'Working with NextPrime was a game-changer! Highly recommended!', 'name'=>'Anamul Haque Adar', 'title'=>'Head of Ideas, Technext'],
                        ['img'=>'img/testimonial_11-190x190.jpg', 'text'=>'Absolutely impressed! Delivered exactly what we needed.', 'name'=>'Farhana Jubayir', 'title'=>'CEO, Apple Inc'],
                        ['img'=>'img/testimonial_22-190x190.jpg', 'text'=>'Fantastic experience! Turned our vision into reality effortlessly.', 'name'=>'Jahid Iqbal', 'title'=>'Team Lead, Design Studio'],
                    ];
                    foreach($feedbacks as $f){
                        echo '<div class="item testimonial text-center">
                                <img src="'.$f['img'].'" alt="Client Photo" height="150">
                                <p>'.$f['text'].'</p>
                                <strong>'.$f['name'].'</strong><br>
                                <span>'.$f['title'].'</span>
                              </div>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contact Form -->
<div class="content-block" id="contact">
    <div class="overlay-3">
        <header class="block-heading text-center"><h1>Contact Form</h1></header>
        <div class="container text-center">
            <div class="row">
                <div class="col-md-6">
                    <?php if ($messageSent): ?>
                        <div class="alert alert-success">Message sent successfully!</div>
                    <?php elseif ($errorMessage): ?>
                        <div class="alert alert-danger"><?= $errorMessage ?></div>
                    <?php endif; ?>
                    <form class="contact-form" action="" method="POST">
                        <input type="text" name="name" placeholder="Name" required>
                        <input type="email" name="email" placeholder="Email" required>
                        <textarea rows="5" name="message" placeholder="Say Something..." required></textarea>
                        <input type="submit" name="submit" value="Submit">
                    </form>
                </div>
                <div class="col-md-6">
                    <div class="contact-info">
                        <p><strong>Address:</strong> Demra - Staff Quarter - Chittagong Rd, Dhaka 1361</p>
                        <p><strong>Cell No:</strong> 01632606827</p>
                        <p><strong>Email:</strong> mahedihasanabir8@gmail.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer id="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">&copy; 2025 Programmer</div>
            <div class="col-sm-6">Presented By <a href="#">Mahedi Hasan</a></div>
        </div>
    </div>
</footer>

<!-- JS -->
<script src="js/jquery-2.1.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/wow.min.js"></script>
<script>
new WOW().init();

// Feedback Carousel
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    autoplay:true,
    autoplayTimeout:3000,
    autoplayHoverPause:true,
    items:1,
    nav:false,
    dots:true
});

// Profile Counters
$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
</script>
</body>
</html>
