<?php
require 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $message = trim($_POST['message']);

    // Validation
    if (empty($name) || empty($email) || empty($message)) {
        die("❌ All fields are required");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("❌ Invalid email address");
    }

    /* ================= DATABASE INSERT ================= */
    $stmt = $conn->prepare(
        "INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)"
    );

    if (!$stmt) {
        die("DB Error: " . $conn->error);
    }

    $stmt->bind_param("sss", $name, $email, $message);
    $stmt->execute();
    $stmt->close();

    /* ================= EMAIL SEND ================= */
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
$mail->Host       = 'smtp.gmail.com';
$mail->SMTPAuth   = true;
$mail->Username   = 'mahedihasanabir8@gmail.com';
$mail->Password   = 'YOUR_16_DIGIT_APP_PASSWORD';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
$mail->Port       = 465;


        $mail->setFrom('mahedihasanabir8@gmail.com', 'Website Contact');
        $mail->addAddress('idbmahedi@gmail.com');

        $mail->isHTML(true);
        $mail->Subject = 'New Contact Message';
        $mail->Body = "
            <b>Name:</b> $name <br>
            <b>Email:</b> $email <br>
            <b>Message:</b><br> $message
        ";

        $mail->send();

        header("Location: index.php?status=success");
        exit();

    } catch (Exception $e) {
        echo "❌ Mail Error: {$mail->ErrorInfo}";
    }

    $conn->close();
}
?>
