<?php
require 'db.php'; // DB connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Prepare statement
    $stmt = $conn->prepare("INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)");
    if ($stmt === false) {
        echo "❌ Error preparing statement: " . htmlspecialchars($conn->error);
        exit;
    }

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    // Validation
    if (empty($name) || empty($email) || empty($message)) {
        echo "❌ All fields are required!";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "❌ Invalid email!";
        exit;
    }

    // Bind parameters and execute
    $stmt->bind_param("sss", $name, $email, $message);
    
    if ($stmt->execute()) {
        // Redirect to index.php
        header("Location: index.php?status=success");
        exit();
    } else {
        echo "❌ Error: " . htmlspecialchars($stmt->error);
    }

    $stmt->close();
    $conn->close();
}
?>