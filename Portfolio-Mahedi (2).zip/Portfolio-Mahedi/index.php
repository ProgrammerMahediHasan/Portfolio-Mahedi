<!DOCTYPE html>
<html lang="en-us">
<head>
    <title>Developer</title>

    <!-- meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- stylesheet -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- google font -->
    <link href='http://fonts.googleapis.com/css?family=Oswald:300,400' rel='stylesheet'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oxygen:400,300' rel='stylesheet' type='text/css'>
    <link href="http://fonts.googleapis.com/css?family=Rouge+Script" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Milonga' rel='stylesheet' type='text/css'>
</head>
<body>
    <div class="content-block" id="header">
        <div id="overlay-1">
            <header id="site-header" class="clearfix">
                <div class="pull-left">
                    <h1><a href="#">Programmer-Mahedi</a></h1>
                </div>
                <div class="pull-right">
                    <nav class="navbar site-nav" role="navigation">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <i class="fa fa-bars fa-2x"></i>
                            </button>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li class="active"><a href="#header"><i class="fa fa-home"></i> <span>Home</span></a></li>
                                <li><a href="#projects"><i class="fa fa-bookmark"></i> Projects</a></li>
                                <li><a href="#services"><i class="fa fa-bullhorn"></i> Profile</a></li>
                                <li><a href="#feedback"><i class="fa fa-thumbs-up"></i> Feedback</a></li>
                                <li><a href="#contact"><i class="fa fa-phone-square"></i> Contact</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </header>
            
            <div class="middle text-center clearfix">
                <div class="container">
                    <h1 class="pro-name">Web Developer</h1>
                    <p class="tagline">Design. Develop. Deliver.</p>
                    <div class="skills"></div>
                    <a href="#contact" target="_blank" class="btn btn-lg btn-hire wow animated zoomIn">Hire Me</a>
                </div>
            </div>
            
            <div class="bottom text-center">
                <a href="#projects"><i class="fa fa-angle-down fa-3x pulse"></i></a>
            </div>
        </div>
    </div>

    
    <!-- Projects Section -->
<div class="content-block text-center" id="projects">
    <header class="block-heading clearfix">
        <h1>My Projects</h1>
    </header>
    <div class="isotope projects-items">
        <!-- Example project item -->
       <div class="element-item grid">
    <div class="effect-zoe">
        <a href="https://shohoz-project.netlify.app/" target="_blank"> <!-- Link to Shohoz -->
            <img class="img-responsive project-image" alt="SHOHOZ.COM" src="img/work1.jpg">
            <figcaption>
                <h2 class="hidden-xs">SHOHOZ.<span>COM</span></h2>

            </figcaption>
        </a>
    </div>
</div>
        
        <div class="element-item grid">
            <div class="effect-zoe">
                <img class="img-responsive project-image" alt="InnoCraft" src="img/work2.jpg">
                <figcaption>
                    <h2 class="hidden-xs">Inno<span>Craft</span></h2>
                </figcaption>
            </div>
        </div>

        <div class="element-item grid">
            <div class="effect-zoe">
                <img class="img-responsive project-image" alt="HRM & COM" src="img/work5.jpg">
                <figcaption>
                    <h2 class="hidden-xs">HRMS &<span> PAYROLL</span></h2>
                </figcaption>
            </div>
        </div>

        <div class="element-item grid">
            <div class="effect-zoe">
                <img class="img-responsive project-image" alt="SHOHOZ.COM" src="img/work4.jpg">
                <figcaption>
                    <h2 class="hidden-xs">SHOHOZ.<span>COM</span></h2>
                </figcaption>
            </div>
        </div>
        <!-- Add more projects similarly -->
    </div>
    <a href="#" class="btn btn-md btn-view">
        <i class="fa fa-eye"></i>
        <span>View All</span>
    </a>
</div>

    <!-- Services Section -->
    <div id="services" class="content-block">
        <div id="numbers" class="parallax">
            <div class="overlay">
                <div class="container-fluid numbers-title">
                    <div class="container">
                        <div class="row block-heading">
                            <h1>A Quick Overview of My Profile</h1>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <ul class="numbersList">
                        <li class="col-md-2 col-sm-4 col-xs-6"><h4>Conferences</h4><span id="number1" class="count1 count-timer">101</span></li>
                        <li class="col-md-2 col-sm-4 col-xs-6"><h4>Lines of Code</h4><span id="number2" class="count2">92</span></li>
                        <li class="col-md-2 col-sm-4 col-xs-6"><h4>Hours of Work</h4><span id="number3" class="count3">54</span></li>
                        <li class="col-md-2 col-sm-4 col-xs-6"><h4>Repositories in Git</h4><span id="number4" class="count4">99</span></li>
                        <li class="col-md-2 col-sm-4 col-xs-6"><h4>Mobile APP</h4><span id="number5" class="count5">124</span></li>
                        <li class="col-md-2 col-sm-4 col-xs-6"><h4>Happy Client</h4><span id="number6" class="count6">45</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Feedback Section -->
    <div class="content-block" id="feedback">
        <header class="block-heading cleafix text-center">
            <h1>Clients Feedback!</h1>
        </header>
        <div class="block-content text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="owl-carousel">
                            <div class="owl-item">
                                <div class="testimonial">
                                    <img alt="Client Photo" height="150px"  src="img/testimonial_31-190x190.jpg">
                                    <p>Working with NextPrime It was a game-changer! Their expertise and support exceeded all expectations. Highly recommended!</p>
                                    <strong>Anamul Haque Adar</strong><br>
                                    <span>Head of Ideas, Technext</span>
                                </div>
                            </div>
                            <div class="owl-item">
                                <div class="testimonial">
                                    <img alt="Client Photo" height="150px" src="img/testimonial_11-190x190.jpg">
                                    <p>Absolutely impressed! NextPrime It delivered exactly what we needed, on time and beyond expectations.</p>
                                    <strong>Farhana Jubayir</strong><br>
                                    <span>CEO, Apple Inc</span>
                                </div>
                            </div>
                            <div class="owl-item">
                                <div class="testimonial">
                                    <img alt="Client Photo" height="150px" src="img/testimonial_22-190x190.jpg">
                                    <p>Fantastic experience! Their professionalism and creativity turned our vision into reality effortlessly.</p>
                                    <strong>Jahid Iqbal</strong><br>
                                    <span>Team Lead, Design Studio</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Section -->
    <div class="content-block" id="contact">
        <div class="overlay-3">
            <header class="block-heading cleafix text-center">
                <h1>Contact</h1>
            </header>
            <div class="block-content text-center">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 wow animated fadeInLeft">
                            <form class="contact-form" action="form.php" method="POST">
                                <input type="text" name="name" placeholder="Name" required>
                                <input type="email" name="email" placeholder="Email" required>
                                <textarea rows="5" name="message" placeholder="Say Something..." required></textarea>
                                <input type="submit" value="Submit">
                            </form>
                        </div>
                        <div class="col-md-6 wow animated fadeInRight">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="contact-info">
                                        <div class="clearfix">
                                            <div class="rotated-icon"><div class="sqaure-nebir"></div><i class="fa fa-map-marker"></i></div>
                                            <p><strong> Address:</strong> Demra - Staff Quarter - Chittagong Rd, Dhaka 1361</p>
                                        </div>
                                        <div class="clearfix">
                                            <div class="rotated-icon"><div class="sqaure-nebir"></div><i class="fa fa-mobile"></i></div>
                                            <p><strong> Cell No:</strong> 01632606827 </p>
                                        </div>
                                        <div class="clearfix">
                                            <div class="rotated-icon"><div class="sqaure-nebir"></div><i class="fa fa-envelope-o"></i></div>
                                            <p><strong> Email:</strong> mahedihasanabir8@gmail.com</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <ul class="social-box">
                                    <li><a class="facebook-icon" href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a class="twitter-icon" href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a class="g-plus-icon" href="#"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a class="linkedin-icon" href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer id="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6"><div class="copyright">&copy; 2025 Programmer</div></div>
                <div class="col-sm-6"><div class="designed-by">Presented By <a href="http://themewagon.com/" target="_blank">Mahedi Hasan</a></div></div>
            </div>
        </div>
    </footer>

    <!-- js -->
    <script>new WOW().init();</script>
    <script src="js/jquery-2.1.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.actual.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.isonscreen.js"></script>
    <script src="js/main.js"></script>
    <script>
        $(document).ready(function(){
            $('.owl-carousel').owlCarousel({
                loop:true,
                margin:10,
                autoplay:true,
                autoplayTimeout:3000,
                autoplayHoverPause:true,
                responsiveClass:true,
                responsive:{
                    0:{items:1},
                    600:{items:1},
                    1000:{items:1}
                }
            })
        });
    </script>
</body>
</html>
